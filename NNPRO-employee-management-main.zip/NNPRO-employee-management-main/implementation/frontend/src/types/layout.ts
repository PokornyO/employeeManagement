import React from "react";

export interface ProviderProps {
    children: React.ReactNode;
}