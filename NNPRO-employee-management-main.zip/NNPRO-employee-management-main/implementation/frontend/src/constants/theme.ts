export const theme = {
    background: '#121212',
    primary: '#001D3D',
    primaryLight: '#03346E',
    secondary: '#1f1f1f',
    text: '#ffffff',
    success: '#4caf50',
    error: '#f44336',
    warning: '#ff9800',
}